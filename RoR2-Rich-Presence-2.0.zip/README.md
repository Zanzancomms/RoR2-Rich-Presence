forked from Kataiser/RoR2-Rich-Presence [![Github all releases](https://img.shields.io/github/downloads/Kataiser/RoR2-Rich-Presence/total.svg)](https://GitHub.com/Kataiser/RoR2-Rich-Presence/releases/)

# RoR2 Rich Presence
Discord Rich Presence for Risk of Rain (thrown together from [Celeste Rich Presence](https://github.com/Kataiser/celeste-rich-presence), which itself is thrown together from an older version of [TF2 Rich Presence](https://github.com/Kataiser/tf2-rich-presence))

![Screenshot](screenshot.png)
![Screenshot](image.png)
(The actual program is nowhere near as nice looking as this)

## Download and running
[RoR2_Rich_Presence_v1.2.zip](https://github.com/Zanzancomms/RoR2-Rich-Presence/releases/download/1.2/RoR2-Rich-Presence-1.2.zip) (8.6 MB)  
Run by running `run.bat` at the same time as the game.
