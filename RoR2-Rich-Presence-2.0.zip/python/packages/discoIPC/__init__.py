"""discoIPC Package."""

__all__ = ['ipc']
